﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cedric.Breeding
{
    public enum Allele
    {
        G,
        Y,
        H,
        W,
        X
           
    }
}
